package com.rxlogix.controllers2

import com.rxlogix.controllers2.co.EmployeeCO
import org.springframework.web.multipart.MultipartFile

class SampleController {

	def index() {}

    def intBinding(Integer intParam, String stringParam) {
        //http://localhost:8080/controllers2/sample/intBinding?intParam=20&stringParam=Sahi
        Person person = new Person(name: stringParam, age: intParam)
//		params.date("dob", "dd-MM-yyyy")
//		println "person1.validate()>>>>>"+person1.validate()
//		Person person1 = new Person(params)
        render intParam
        render stringParam
        render "<br>"
        render person
    }

	//autoBinding
	def autoBinding() {
        //http://localhost:8080/controllers2/sample/intBinding?intParam=20&stringParam=Sahi&dateParam=20-07-2019
        render params.intParam
		render params.stringParam
		render params.dateParam
	}

	//params magic
	def paramsConversion() {
//        http://localhost:8080/controllers2/sample/paramsConversion?age=20&dob=20-02-2019&name=Prashant
		Integer age = params.int("age")
		String name = params.name
		Date dob = params.date("dob", "dd-MMM-yyyy")
		Person person = new Person(name: name, age: age, dob:dob)

		render name
		render age
		render dob
        render "<br>"
        render person
	}

	def fetchList() {
//        http://localhost:8080/controllers2/sample/fetchList?items=elem1&items=elem2&items=elem3
		List list = params.list("items")
		render list
	}

	def dataBindWithErrors() {
		println "------------------------------------ " + params
        Employee b = new Employee(params)
		println b.hasErrors()
		println b.errors.allErrors
		println b.errors.hasFieldErrors()
		println b.errors.getFieldErrors()
		println b.errors.getFieldError("dob")
		if (b.hasErrors()) {
			println "The value ${b.errors.getFieldError('age')}"
			if (b.errors.hasFieldErrors("age")) {
				println b.errors.getFieldError("age").rejectedValue
			}
		}

		render b.properties
	}

	def signleEndedAssociation() {
		def b = new Employee(params)
//        http://localhost:8080/controllers2/sample/signleEndedAssociation?dept.id=1
		render b.properties
	}

	def multipleDomainBinding() {
		def b = new Employee(params)
//        http://localhost:8080/controllers2/sample/signleEndedAssociation?dept.id=1
		render b.properties
	}

	def usingCO(EmployeeCO employeeCO){
		println employeeCO.properties
		Employee employee = new Employee(employeeCO.properties)
		render employeeCO.validate()
		render "<br>"
		render employee.properties


//		render "<br>"
//		render "-------------------------------------"
//		render employeeCO.errors
//		render "<br>"
//		render employeeCO.validate()
	}

	def fileUpload(){

	}


	def gFileUpload(){
		MultipartFile myFile = params.myFile
		File file = new File("/Users/prashantsahi/${myFile.originalFilename}")
		file.bytes = myFile.bytes
		Employee emp = new Employee()
		emp.file= myFile.bytes
		render file.text
		render file.size()
		render "<br>"
		render myFile.inputStream.text
		render "<br>"
		render file.name
        render "<br>"
		render "Done!!!"
	}

	def createOrderPDF(){
		File file = new File("/Users/prashantsahi/test_upload.groovy")
		byte[] orderPDF = file.getBytes()
		response.setHeader("Content-disposition", "attachment; filename=" + file.name)
		response.contentLength = orderPDF.length
		response.outputStream << orderPDF
	}
}
