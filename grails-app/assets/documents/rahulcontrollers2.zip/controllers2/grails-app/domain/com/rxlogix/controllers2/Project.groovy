package com.rxlogix.controllers2

class Project {

	static constraints = {
	}
}
