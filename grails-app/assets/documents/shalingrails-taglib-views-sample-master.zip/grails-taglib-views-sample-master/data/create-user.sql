--run below sql statement from a user in the DB for application

--run as many as you want after app start
INSERT INTO STUDENT(age, city, country, deleted, gender, name) VALUES (27, 'Noida', 'India', 0, 'Male', 'Parveen Soni');

Commit;