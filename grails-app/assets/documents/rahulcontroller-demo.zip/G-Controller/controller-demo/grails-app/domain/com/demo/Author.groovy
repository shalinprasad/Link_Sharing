package com.demo

class Author {

    Long id
    String name
    int age

    static constraints = {
    }
}
