package com.demo

import grails.converters.JSON

class TestController {

    def beforeInterceptor = {
        println "before 123interceptor called."
    }

//    def scaffold = true

//    def index() {
//        render "index action called"
//    }
//
//    def json(){
//        render ([a:12] as JSON)
//    }
//
    def test(Long id, String username){
        [username: username, id:id]
    }
//
    def test1(){
        render(view: 'test',model: [username: 'Tushar sdfasfsa'])
    }

    def newAction(){
//       render "abc"
        session.setAttribute('key',12)
        flash.value = "Test"
        println "sdfsad"
        render(view: 'newAction',model: [data:500])
    }

    def bindAuthor(){
        Author author = new Author(params)
        author.save(flush:true,failOnError:true)
        println ">>>>>>>>>>>>>>>>>>>"+author.name
        println ">>>>>>>>>>>>>>>>>>>"+author.age
        redirect(controller:'author',action:'index')
    }

    def bindProp(){
        println "params : "+params
        Author author = Author.get(params.id)
//        author.age = age
        author.properties = params
        println ">>>>>>>s>>>>>>>>>>>>"+author.age
        author.save(flush:true,failOnError:true)
        redirect(controller:'author',action:'index')
    }

    def bindDataDemo(){
        println "params : "+params
        Author author = Author.get(params.id)
        bindData(author,params,[exclude:'class'])
        author.save(flush:true,failOnError:true)
        redirect(controller:'author',action:'index')
    }
}
