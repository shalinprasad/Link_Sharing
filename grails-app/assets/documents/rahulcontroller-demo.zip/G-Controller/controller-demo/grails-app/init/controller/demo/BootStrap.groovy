package controller.demo

class BootStrap {

    def init = { servletContext ->
    }
    def destroy = {
    }
}
